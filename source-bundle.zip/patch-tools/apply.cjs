const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict');
const target=process.argv[2]||path.resolve(__dirname,'../plugins/pdf-plus/main.js');
const source=fs.readFileSync(target,'utf8');
const marker='// PDF++ Vietnamese UI v1';
if(source.includes(marker)){console.log('Bản dịch đã được áp dụng.');process.exit(0);}
const map=new Map(fs.readFileSync(path.join(__dirname,'vi.txt'),'utf8').split(/\r?\n/).filter(Boolean).map(line=>{const i=line.indexOf('|');assert(i>0);return[line.slice(0,i),line.slice(i+1)];}));
const stats={translated:0,missing:[]};
const quote='"(?:\\\\.|[^"\\\\])*"';
const context=new RegExp('(\\.(?:setName|setDesc|setTooltip|setButtonText|setPlaceholder|setTitle|addHeading|addDesc)\\(|id:'+quote+',name:|\\btext:)('+quote+')','g');
const result=source.replace(context,(all,prefix,literal)=>{
 const value=JSON.parse(literal),translation=map.get(value);
 if(!translation){if(/^[A-Z][a-z]/.test(value)&&value.includes(' '))stats.missing.push(value);return all;}
 stats.translated++;return prefix+JSON.stringify(translation);
})+'\n'+marker+'\n';
assert(stats.translated>250,'Too few UI strings matched; review plugin version.');
new vm.Script(result,{filename:target});
// UI-only substitutions must preserve commands, settings keys and interpolation syntax.
const commandIds=s=>[...s.matchAll(/id:"([a-z][a-z0-9-]+)",name:/g)].map(m=>m[1]);
assert.deepEqual(commandIds(source),commandIds(result));
const templates=s=>[...s.matchAll(/`(?:\\.|[^`\\])*`/g)].map(m=>m[0]);
assert.deepEqual(templates(source),templates(result));
if(!fs.existsSync(target+'.before-vi.bak'))fs.copyFileSync(target,target+'.before-vi.bak');
fs.writeFileSync(target,result);
fs.writeFileSync(path.join(__dirname,'translation-report.json'),JSON.stringify({...stats,missing:[...new Set(stats.missing)]},null,2)+'\n');
console.log(JSON.stringify({translated:stats.translated,untranslatedUIStrings:[...new Set(stats.missing)].length,syntax:'OK',commandIds:'unchanged',templates:'unchanged'}));
