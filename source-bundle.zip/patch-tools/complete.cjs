const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),cp=require('node:child_process');
const acorn=require('./acorn.cjs');
const target=process.argv[2]||path.resolve(__dirname,'../plugins/pdf-plus/main.js');
const backup=target+'.before-vi.bak';
assert(fs.existsSync(backup),'Original backup is required');
fs.copyFileSync(backup,target);
cp.execFileSync(process.execPath,[path.join(__dirname,'apply.cjs'),target],{stdio:'pipe'});
const source=fs.readFileSync(target,'utf8');
const candidates=JSON.parse(fs.readFileSync(path.join(__dirname,'remaining.json'),'utf8'));
const decode=s=>s.replace(/\\n/g,'\n');
const entries=fs.readFileSync(path.join(__dirname,'extra-prefixes.txt'),'utf8').split(/\r?\n/).filter(Boolean).map(l=>{const i=l.indexOf('|');assert(i>0);return[decode(l.slice(0,i)),decode(l.slice(i+1))];}).sort((a,b)=>b[0].length-a[0].length);
const exact=new Map();
const baseMap=new Map(fs.readFileSync(path.join(__dirname,'vi.txt'),'utf8').split(/\r?\n/).filter(Boolean).map(l=>{const i=l.indexOf('|');return[l.slice(0,i),l.slice(i+1)];}));
for(const [en,vi]of baseMap)if(en.length>=8)exact.set(en,vi);
for(const c of candidates){const m=entries.find(([prefix])=>c.text.startsWith(prefix));if(m)exact.set(c.text,m[1]);}
// Include labels containing only one word, and the two registered labels not caught by the prose audit.
for(const [en,vi]of entries)exact.set(en,vi);
const tokens=[...acorn.tokenizer(source,{ecmaVersion:'latest'})],edits=[];
for(let i=0;i<tokens.length;i++){
 const t=tokens[i];if(t.start<660000||!['string','template'].includes(t.type.label))continue;
 if(tokens[i+1]?.type.label===':'&&['{',',','case'].includes(tokens[i-1]?.type.label))continue; // preserve object keys and switch labels, not ternary display values
 const vi=exact.get(t.value);if(vi===undefined||vi===t.value)continue;
 const content=t.type.label==='string'?JSON.stringify(vi):vi.replace(/\\/g,'\\\\').replace(/`/g,'\\`').replace(/\$\{/g,'\\${');
 edits.push({start:t.start,end:t.end,content});
}
let result=source;for(const e of edits.reverse())result=result.slice(0,e.start)+e.content+result.slice(e.end);
const shape=s=>[...acorn.tokenizer(s,{ecmaVersion:'latest'})].map(t=>['string','template'].includes(t.type.label)?t.type.label:[t.type.label,t.value]);
assert.deepEqual(shape(source),shape(result),'Translations must not change executable token structure');
// Existing user-defined copy format/color names stay in data.json. Translate their built-in names only for display.
const tooltip=/setTooltipToActionItem\(e,t\)\{[\s\S]*?\}\s*updateTooltips\(\)/;
const old=result.match(tooltip)?.[0];assert(old,'Toolbar tooltip function not found');
const replacement='setTooltipToActionItem(e,t){let i=e.querySelector(":scope > ."+Ei.CLS+"-item-inner"),r=pdfPlusViDisplayText(this.plugin.settings.copyCommands[this.actionIndex].name),o=this.plugin.settings.quietColorPaletteTooltip,s=t!==null?o?pdfPlusViDisplayText(t):`Sao chép liên kết theo định dạng “${r}” và ${pdfPlusViDisplayText(this.plugin.settings.selectionBacklinkVisualizeStyle)} màu ${pdfPlusViDisplayText(t.toLowerCase())}`:o?"Không chỉ định màu":`Sao chép liên kết theo định dạng “${r}” mà không chỉ định màu`;(0,ze.setTooltip)(i,s)}updateTooltips()';
result=result.replace(old,replacement);
for(const [from,to]of [['a.addOption(l,d)','a.addOption(l,pdfPlusViDisplayText(d))'],['s.addOption(d,h)','s.addOption(d,pdfPlusViDisplayText(h))'],['o.addOption(s,a)','o.addOption(s,pdfPlusViDisplayText(a))']]){
 assert.equal(result.split(from).length,2,'Dropdown display hook must be unique: '+from);
 result=result.replace(from,to);
}
result+='\nfunction pdfPlusViDisplayText(value){const labels={"Quote in callout":"Trích dẫn trong khối chú dẫn",Quote:"Trích dẫn",Link:"Liên kết",Embed:"Nhúng",Callout:"Khối chú dẫn",red:"đỏ",yellow:"vàng",green:"xanh lá",blue:"xanh dương",purple:"tím",orange:"cam",pink:"hồng",cyan:"xanh lơ",note:"ghi chú",important:"quan trọng",highlight:"tô sáng",underline:"gạch chân",strikethrough:"gạch ngang",squiggly:"gạch lượn sóng",outline:"đường viền"};return labels[value]||labels[String(value).toLowerCase()]||value;}\n// PDF++ Vietnamese UI v2\n';
acorn.parse(result,{ecmaVersion:'latest'});
result=result.replace('Quote:"Trích dẫn",','Default:"Mặc định",None:"Không có",Never:"Không bao giờ",Always:"Luôn luôn",Enabled:"Đã bật",Disabled:"Đã tắt",Yes:"Có",No:"Không",Portrait:"Dọc",Landscape:"Ngang",Vertical:"Dọc",Horizontal:"Ngang",Continuous:"Liên tục",Border:"Đường viền",Solid:"Nét liền",Dashed:"Nét đứt",Dotted:"Nét chấm",Quote:"Trích dẫn",');
const ids=s=>[...s.matchAll(/id:"([a-z][a-z0-9-]+)",name:/g)].map(m=>m[1]);assert.deepEqual(ids(source),ids(result));
const settings=s=>[...s.matchAll(/this\.add[A-Za-z]+Setting\("([^"\n]+)"/g)].map(m=>m[1]);assert.deepEqual(settings(source),settings(result));
const remaining=[];for(const t of acorn.tokenizer(result,{ecmaVersion:'latest'})){if(t.start<660000||!['string','template'].includes(t.type.label))continue;let v=t.value;if(typeof v==='string'&&v.length>=8&&/[A-Za-z]{2} [a-zA-Z]{2}/.test(v)&&!/[ăâđêôơư\u1ea0-\u1ef9]/i.test(v))remaining.push(v);}
fs.writeFileSync(target,result);
fs.writeFileSync(path.join(__dirname,'completion-report.json'),JSON.stringify({additionalTranslations:edits.length,settingsKeysPreserved:true,commandIdsPreserved:true,remaining:[...new Set(remaining)]},null,2)+'\n');
console.log(JSON.stringify({additionalTranslations:edits.length,syntax:'OK',settingsKeys:'unchanged',commandIds:'unchanged'}));
